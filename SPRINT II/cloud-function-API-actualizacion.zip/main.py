import os
import requests
from flask import jsonify
from google.cloud import storage
import json
import random 
import pandas as pd

# Se agrega una función aleatoria para modificar ligeramente la longitud y latitud, con el objetivo de obtener resultados variados
def get_random_offset():
    return random.uniform(-0.01, 0.01)

def search_restaurant_5(request):
    locations = {
        "California": ["San Mateo","San Francisco", "Los Angeles", "San Diego", "Sacramento", "Santa Clara", "Fresno","Alameda", "Orange","Kern","Riverside", "San Joaquin","Contra Costa","Ventura"],
        "Texas": ["Harris","Dallas","Tarrant","Bexar","Travis","Collin","Denton","Hidalgo"," El Paso","Fort Bend","Montgomery","Williamson","Cameron","Nueces"],
        "Florida":["Miami-Dade","Broward","Palm Beach","Hillsborough","Orange","Pinellas","Duval","Lee","Polk","Brevard","Volusia","Pasco","Seminole","Sarasota"],
        "NuevaYork":["Kings","Queens","New York","Bronx","Richmond","Suffolk","Nassau","Westchester","Erie","Monroe","Onondaga","Orange","Rockland","Albany"],
        "Illinois": ["Chicago","Aurora","Rockford","Springfield","Joliet","Naperville","Peoria","Champaign","Belleville","Bloomington"," Decatur","Evanston"]
}
    api_key = API_KEY #agregar key generado
    
    for state, cities in locations.items():
        random.shuffle(cities)  #  Se reorganiza las ciudades
        restaurant_data = []
        for city in cities:
            # Se obtiene las coordenadas de la ciudad
            geocoding_url = f'https://maps.googleapis.com/maps/api/geocode/json?address={city},{state}&key={api_key}'
            geocoding_response = requests.get(geocoding_url)
            geocoding_result = geocoding_response.json()['results'][0]
            location_lat = geocoding_result['geometry']['location']['lat']+ get_random_offset()
            location_lng = geocoding_result['geometry']['location']['lng']+ get_random_offset()

            # Se busca los parametros
            query = 'restaurant'
            radius = 50000
            fields = 'name,rating,formatted_address,geometry,reviews'

            # Se busca las coordenadas de restaurantes dentro de 50 km 
            url = f'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location={location_lat},{location_lng}&radius={radius}&type={query}&key={api_key}'

            # Se realiza la solicitud y se obtiene los resultados
            response = requests.get(url)
            results = response.json()['results']

            # Por cada resultado se obtiene la data necesaria
            for result in results:
                place_id = result['place_id']
                details_url = f'https://maps.googleapis.com/maps/api/place/details/json?place_id={place_id}&fields={fields}&key={api_key}'
                details_response = requests.get(details_url)
                details = details_response.json()['result']

                # Se obtiene la data y se almacena en el diccionario
                restaurant = {
                    'name': details['name'],
                    'rating': details.get('rating', 'N/A'),
                    'address': details['formatted_address'],
                    'latitude': details['geometry']['location']['lat'],
                    'longitude': details['geometry']['location']['lng'],
                    'reviews': details.get('reviews', []),
                    'place_id': place_id
                }
                restaurant_data.append(restaurant)

        # Se normaliza el JSON
        df = pd.json_normalize(restaurant_data)

        # Se convierte los datos en diccionario
        restaurant_data_flat = df.to_dict('records') 

        #S Guardar en archivo JSON
        storage_client = storage.Client()
        bucket_name = 'extra_sources'
        file_name = f"{state}.json"
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(f"Details-Api/{file_name}")
        blob.upload_from_string(json.dumps(restaurant_data_flat, indent=1, separators=(',', ': ')))

    return 'Done'
        name = request_json['name']
    elif request_args and 'name' in request_args:
        name = request_args['name']
    else:
        name = 'World'
    return 'Hello {}!'.format(name)
