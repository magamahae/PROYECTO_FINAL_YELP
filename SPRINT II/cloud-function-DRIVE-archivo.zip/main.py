def load_files(event, context):
    # Obtén el nombre del archivo
    filename = event['name']

    # Obtén el contenido del archivo
    content = event['content']

    # Carga el archivo al Storage
    bucket = 'my-bucket'
    blob = bucket.blob(filename)
    blob.upload_from_string(content)

    print('El archivo', filename, 'se ha cargado correctamente al Storage')
    print(f"Event type: {event_type}")
    print(f"Bucket: {bucket}")
    print(f"File: {name}")
    print(f"Metageneration: {metageneration}")
    print(f"Created: {timeCreated}")
    print(f"Updated: {updated}")
