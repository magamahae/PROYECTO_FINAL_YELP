# nombre de la funcion: function-fecha
import pandas as pd

def leer_archivo(f_path):
    """
    Lee el archivo según su extensión. Disparado por la funcion "captura_evento"
    Args:
        event (dict): Event payload.
        file_path (str): ruta del archivo
        file_type (str): tipo del archivo
    """
    # Extraer el tipo de archivo
    f_type = f_path.split('.')[-1]
    
    ############### Revisando si archivo es csv #########################
    if f_type == 'csv':
        # Leyendo archivo en dataframe
        df = pd.read_csv(f_path)
        print('se leyo csv')
    
    ############## Revisando si archivo es json ############################   
    elif f_type == 'json':
        try:
            # Intentar leer el archivo json como si no tuviera saltos de linea
            df = pd.read_json(f_path)
            print('se leyo json')
        except ValueError as e:
            if 'Trailing data' in str(e):
                # Leer el archivo json conteniendo saltos de linea
                df = pd.read_json(f_path, lines = True)
                print('se leyo json')
            else:
                # Cualquier otro error
                print('Ocurrió un error cargando el archivo JSON:', e)

    ################# Revisar si el archivo es tipo parquet ########################
    elif f_type == 'parquet':
        # Leyendo archivo en dataframe
        df = pd.read_parquet(f_path)
        print('se leyo parquet')

    ################ Revisar si el archivo es tipo pkl (Pickle) #####################
    elif f_type == 'pkl':
        try:
            # Leyendo archivo en DataFrame desde Google Cloud Storage
            df = pd.read_pickle(f_path)
            print('se leyo pkl')
        except Exception as e:
            print(f'Ocurrió un error al leer el archivo Pickle: {e}')
    
  
    return df

def limpiar_df(df, dataset, table_name):
    """
    Limpia el df. Disparado por la funcion "captura_evento"
    Args:
        data (DataFrame): dataframe a limpiar.
    """
    
    try:
        if dataset == "Google_Maps":
            if  table_name == "review":
                 df.drop_duplicates(inplace=True)
            elif  table_name == "business":
                 df.drop_duplicates(inplace=True)

        if dataset == "Yelp":
            if  table_name == "review.":
                df.drop(columns=["cool","funny","useful"], inplace=True)
                df.rename(columns={"text":"opinion", "stars":"rating"}, inplace=True)
                df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
                df['date'] = pd.to_datetime(df['date'], format='%Y-%m-%d')
                print('se limpio')
    
            elif table_name == "business.":
                df = df.loc[:, ~df.columns.duplicated()]
                df['state'] = df['state'].shift(-3)
                df.loc[150343, 'state'] = 'IN'
                df.loc[150344, 'state'] = 'IL'
                df.loc[150345, 'state'] = 'FL'
                df = df[df["state"].isin(["IL", "CA", "TX", "NY", "FL"])]
                df = df[df['categories'].str.contains('restaurants')]
                df.drop(columns=["postal_code", "is_open", "attributes", "hours"], inplace=True)
                df.drop_duplicates(inplace=True)
                print('se limpio')

            elif table_name == "user":
                df.drop(columns=["Unnamed: 0","name","yelping_since","funny","cool","elite","fans","average_stars","compliment_hot","compliment_more","compliment_profile","compliment_cute","compliment_list","compliment_note","compliment_plain","compliment_cool","compliment_funny","compliment_writer","compliment_photos"],inplace=True)
                df.rename(columns={"review_count":"num_of_reviews"}, inplace=True)
                print('se limpio')
        
            elif table_name == "tip":
                df.rename(columns={"text":"opinion"}, inplace=True)
                print('se limpio')
                
        return df

    except Exception as e:
        print(f"An error occurred: {e}")

def cargar_df(project, dataset, table, df):
    """
    Carga el df limpio en bigquery. Disparado por la funcion "captura_evento"
    Args:
        project_id (str): nombre del proyecto
        dataset (str): ubicacion del dataset de destino en bigquery
        table_name (str): nombre de la tabla de destino en bigquery
        data_limpia (DataFrame): dataframe limpio para cargar a bigquery
    """
    
    try:
        # convierte todo el dataset a str para almacenar
        df = df.astype(str)
        
        # guarda el dataset en una ruta predefinida y si la tabla ya está creada la reemplaza
        df.to_gbq(destination_table = dataset + table, 
                    project_id = project,
                    table_schema = None,
                    if_exists = 'replace',
                    progress_bar = False, 
                    auth_local_webserver = False, 
                    location = 'southamerica-east1')
            
    except Exception as e:
        print(f"An error occurred: {e}")

def captura_evento(event, context):
    """
    Triggered by a change to a Cloud Storage bucket.
    Args:
        event (dict): Event payload.
    """

    try:
        # Obteniendo ruta de archivo modificado y tipo de archivo
        file_bucket = event["bucket"]
        file_path = event['name']
        file_name = file_path.split('/')[-1].split('.')[-2]
        full_path = 'gs://' + file_bucket + '/' + file_path
        
        # Ejecuta el código si los archivos se cargan en la carpeta correcta del bukcet
        if '/' in file_path:
            main_folder = file_path.split('/')[0]

            # Especifica el conjunto de datos y la tabla donde va a almacenar en bigquery
            if main_folder == "Yelp":
                # Especifica proyecto, conjunto de datos y tabla de bigquery a trabajar
                project_id = 'axial-triode-410618'
                dataset = "Yelp."
                table_name = file_name
                print('se cargo la carpeta')
            
             # Especifica el conjunto de datos y la tabla donde va a almacenar en bigquery
           # elif main_folder == "Google_Maps":
            #    # Especifica proyecto, conjunto de datos y tabla de bigquery a trabajar
            #    project_id = 'axial-triode-410618'
             #   dataset = "Google_Maps."
              #  table_name = file_name
                
                print(table_name)
                # crea el df segun el tipo de archivo
                data = leer_archivo(full_path)

                # llama la funcion para limpiar el df
                data_limpia = limpiar_df(data, dataset, table_name)
                
                # llama a la funcion para cargar el df
                cargar_df(project_id, dataset, table_name, data_limpia)

    except Exception as e:
        print(f"An error occurred: {e}")
